require(["modules/jquery-mozu",
        "underscore",
        "hyprlive",
        "modules/backbone-mozu",
        "modules/views-messages",
        "modules/cart-monitor",
        'hyprlivecontext',
        'modules/editable-view',
        'modules/preserve-element-through-render',
        'modules/checkout/models-checkout-page',
        'modules/checkout/steps/views-base-checkout-step',
        'modules/checkout/steps/step1/views-shipping-info',
        'modules/checkout/steps/step2/views-shipping-methods',
        'modules/checkout/steps/step3/views-payments',
        'modules/checkout/contact-dialog/views-contact-dialog',
        'modules/on-image-load-error',
        'modules/block-ui'
    ],
    function($, _, Hypr, Backbone, messageViewFactory, CartMonitor, HyprLiveContext, EditableView, preserveElements,
        CheckoutModels, CheckoutStepView, ShippingDestinationsView, ShippingMethodsView, PaymentView, ContactDialogView, onImageLoadError, blockUiLoader) {

        var OrderSummaryView = Backbone.MozuView.extend({
            templateName: 'modules/multi-ship-checkout/checkout-order-summary',
            initialize: function() {
                this.listenTo(this.model.get('billingInfo'), 'orderPayment', this.onOrderCreditChanged, this);
                $(".mz-order-summary-image img, img[data-mz-check-image]").each(function() {
                    onImageLoadError.checkImage(this);
                });
            },
            render: function() {
                Backbone.MozuView.prototype.render.call(this);
                $(".mz-order-summary-image img, img[data-mz-check-image]").on("error", function() {
                    onImageLoadError.checkImage(this);
                });
            },
            editCart: function() {
                window.location = (HyprLiveContext.locals.siteContext.siteSubdirectory || '') + "/cart";
            },

            onOrderCreditChanged: function(order, scope) {
                this.render();
            },
            // override loading button changing at inappropriate times
            handleLoadingChange: function() {}
        });

        var poCustomFields = function() {

            var fieldDefs = [];

            var isEnabled = HyprLiveContext.locals.siteContext.checkoutSettings.purchaseOrder &&
                HyprLiveContext.locals.siteContext.checkoutSettings.purchaseOrder.isEnabled;

            if (isEnabled) {
                var siteSettingsCustomFields = HyprLiveContext.locals.siteContext.checkoutSettings.purchaseOrder.customFields;
                siteSettingsCustomFields.forEach(function(field) {
                    if (field.isEnabled) {
                        fieldDefs.push('purchaseOrder.pOCustomField-' + field.code);
                    }
                }, this);
            }

            return fieldDefs;

        };

        var visaCheckoutSettings = HyprLiveContext.locals.siteContext.checkoutSettings.visaCheckout;
        var pageContext = require.mozuData('pagecontext');


        var CouponView = Backbone.MozuView.extend({
            templateName: 'modules/checkout/coupon-code-field',
            handleLoadingChange: function(isLoading) {
                // override adding the isLoading class so the apply button
                // doesn't go loading whenever other parts of the order change
            },
            initialize: function() {
                var me = this;
                this.listenTo(this.model, 'change:couponCode', this.onEnterCouponCode, this);
                this.codeEntered = !!this.model.get('couponCode');
                this.$el.on('keypress', 'input', function(e) {
                    if (e.which === 13) {
                        if (me.codeEntered) {
                            me.handleEnterKey();
                        }
                        return false;
                    }
                });
            },
            onEnterCouponCode: function(model, code) {
                if (code && !this.codeEntered) {
                    this.codeEntered = true;
                    this.$el.find('button').prop('disabled', false);
                }
                if (!code && this.codeEntered) {
                    this.codeEntered = false;
                    this.$el.find('button').prop('disabled', true);
                }
            },
            autoUpdate: [
                'couponCode',
                'errorMessage'
            ],
            addCoupon: function(e) {
                // add the default behavior for loadingchanges
                // but scoped to this button alone
                var self = this;
                this.$el.addClass('is-loading');
                if(self.model.get('errorMessage')){
                    self.model.unset('errorMessage');
                    self.render();
                }
                this.model.addCoupon().ensure(function() {
                    self.$el.removeClass('is-loading');
                    self.model.unset('couponCode');
                    self.render();
                });
            },
            handleEnterKey: function() {
                this.addCoupon();
            }
        });

        var CommentsView = Backbone.MozuView.extend({
            templateName: 'modules/checkout/comments-field',
            autoUpdate: ['shopperNotes.comments']
        });

        var attributeFields = function() {
            var me = this;

            var fields = [];

            var storefrontOrderAttributes = require.mozuData('pagecontext').storefrontOrderAttributes;
            if (storefrontOrderAttributes && storefrontOrderAttributes.length > 0) {

                storefrontOrderAttributes.forEach(function(attributeDef) {
                    fields.push('orderAttribute-' + attributeDef.attributeFQN);
                }, this);

            }

            return fields;
        };

        var ReviewOrderView = Backbone.MozuView.extend({
            templateName: 'modules/checkout/step-review',
            autoUpdate: [
                'createAccount',
                'agreeToTerms',
                'emailAddress',
                'password',
                'confirmPassword'
            ].concat(attributeFields()),
            renderOnChange: [
                'createAccount',
                'isReady'
            ],
            initialize: function() {
                var me = this;
                this.$el.on('keypress', 'input', function(e) {
                    if (e.which === 13) {
                        me.handleEnterKey();
                        return false;
                    }
                });
                this.model.on('passwordinvalid', function(message) {
                    me.$('[data-mz-validationmessage-for="password"]').text(message);
                });
                this.model.on('userexists', function(user) {
                    me.$('[data-mz-validationmessage-for="emailAddress"]').html(Hypr.getLabel("customerAlreadyExists", user, encodeURIComponent(window.location.pathname)));
                });
            },

            submit: function() {
                var self = this;
                _.defer(function() {
                    self.model.submit();
                });
            },
            handleEnterKey: function() {
                this.submit();
            }
        });

        var ParentView = function(conf) {
            var gutter = parseInt(Hypr.getThemeSetting('gutterWidth'), 10);
            if (isNaN(gutter)) gutter = 15;
            var mask;
            conf.model.on('beforerefresh', function() {
                killMask();
                conf.el.css('opacity', 0.5);
                var pos = conf.el.position();
                mask = $('<div></div>', {
                    'class': 'mz-checkout-mask'
                }).css({
                    width: conf.el.outerWidth() + (gutter * 2),
                    height: conf.el.outerHeight() + (gutter * 2),
                    top: pos.top - gutter,
                    left: pos.left - gutter
                }).insertAfter(conf.el);
            });

            function killMask() {
                conf.el.css('opacity', 1);
                if (mask) mask.remove();
            }
            conf.model.on('refresh', killMask);
            conf.model.on('error', killMask);
            return conf;
        };

        $(document).ready(function() {

            var $checkoutView = $('#checkout-form'),
                checkoutData = require.mozuData('checkout');

            var checkoutModel = window.order = new CheckoutModels(checkoutData),
                checkoutViews = {
                    parentView: new ParentView({
                        el: $checkoutView,
                        model: checkoutModel
                    }),
                    steps: {
                        shippingAddress: new ShippingDestinationsView({
                            el: $('#step-shipping-address'),
                            model: checkoutModel.get("shippingStep")
                        }),
                        shippingInfo: new ShippingMethodsView({
                            el: $('#step-shipping-method'),
                            model: checkoutModel.get('shippingInfo')
                        }),
                        paymentInfo: new PaymentView({
                            el: $('#step-payment-info'),
                            model: checkoutModel.get('billingInfo')
                        })
                    },
                    orderSummary: new OrderSummaryView({
                        el: $('#order-summary'),
                        model: checkoutModel
                    }),
                    couponCode: new CouponView({
                        el: $('#coupon-code-field'),
                        model: checkoutModel
                    }),
                    comments: Hypr.getThemeSetting('showCheckoutCommentsField') && new CommentsView({
                        el: $('#comments-field'),
                        model: checkoutModel
                    }),
                    reviewPanel: new ReviewOrderView({
                        el: $('#step-review'),
                        model: checkoutModel
                    }),
                    messageView: messageViewFactory({
                        el: $checkoutView.find('[data-mz-message-bar]'),
                        model: checkoutModel.messages
                    }),
                    contactDialog: new ContactDialogView({
                        el: $("[mz-modal-contact-dialog]"),
                        model: checkoutModel.get('dialogContact'),
                        messagesEl: $("[mz-modal-contact-dialog]").find('[data-mz-message-bar]')
                    })
                };

            window.checkoutViews = checkoutViews;

            checkoutModel.on('complete', function() {
                CartMonitor.setCount(0);
                window.location = "/checkoutv2/" + checkoutModel.get('id') + "/confirmation";
            });



            var $reviewPanel = $('#step-review');
            checkoutModel.on('change:isReady', function(model, isReady) {
                if (isReady) {
                    setTimeout(function() { window.scrollTo(0, $reviewPanel.offset().top); }, 750);
                }
            });
            checkoutModel.on('error', function() {
                blockUiLoader.unblockUi();
            });
            _.invoke(checkoutViews.steps, 'initStepView');
            checkoutViews.contactDialog.render();
            checkoutViews.orderSummary.render();
            $checkoutView.noFlickerFadeIn();

        });
    });