﻿Ext.widget({
    xtype: 'mz-form-webpage',
    items: [
       
    ]
});