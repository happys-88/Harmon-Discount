Ext.widget({
    xtype: 'mz-form-imagewidget'
});