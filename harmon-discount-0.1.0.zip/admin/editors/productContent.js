﻿Ext.widget({
    xtype: 'mz-form-productPage'
});