﻿Ext.widget({
    xtype: 'mz-form-templatecontent',
    title: 'Shared Template Content'
});